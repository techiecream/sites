<?php

namespace SecurityAudit;

use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use PHPMailer\PHPMailer\PHPMailer;

class Config
{
    public const MIN_PHP_VERSION = '8.0.0';
    public const MIN_PHPMailER_VERSION = '6.5.1';
    public const MIN_TCPDF_VERSION = '6.5.0';
    public const DEPRECATED_FUNCTIONS = [
        'mysql_connect' => 'Use mysqli_connect or PDO instead.',
        'mysql_query' => 'Use mysqli_query or PDO instead.',
        'mysql_fetch_array' => 'Use mysqli_fetch_array or PDO instead.',
        'ereg' => 'Use preg_match instead.',
        'eregi' => 'Use preg_match instead.',
        'split' => 'Use explode instead.',
        'mysql_pconnect' => 'Use mysqli_connect or PDO instead.',
        'mysql_db_query' => 'Use mysqli_query or PDO instead.'
    ];
    public const DEFAULT_EXCLUSIONS = [
        'bootstrap/',// Exclude the PHPMailer directory and all its subdirectories
        'css/',// Exclude the PHPMailer directory and all its subdirectories
        'images/',
        'audit.php',
        'scripts/',
        'deploy/',
        'vcs/',
        'PHPMailer/', // Exclude the PHPMailer directory and all its subdirectories
        'tcpdf/', // Exclude the tcpdf directory and all its subdirectories
        'mail/', // Exclude the mail directory and all its subdirectories

    ];
        public const CODING_STANDARD_RULES = [
        'function_naming' => '/^[a-z][a-zA-Z0-9]*$/' // Function names should be camelCase
    ];
}
//logg
class Logger
{
    public static function log($message, $level = 'INFO', $logFile = 'audit_log.txt')
    {
        $timestamp = date('Y-m-d H:i:s');
        $formattedMessage = "[$timestamp] [$level] $message";
        file_put_contents($logFile, $formattedMessage . PHP_EOL, FILE_APPEND);
    }
}

class VersionChecker
{
    public static function getPHPMailerVersion($path)
    {
        if (file_exists($path)) {
            require $path;
            if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
                return PHPMailer::VERSION;
            }
        }
        return 'Not available';
    }

    public static function getTCPDFVersion($path)
    {
        if (file_exists($path)) {
            $fileContent = file_get_contents($path);
            if (preg_match('/Version\s*:\s*([0-9]+\.[0-9]+\.[0-9]+)/', $fileContent, $matches)) {
                return $matches[1];
            }
        }
        return 'Not available';
    }

    public static function versionCompare($version1, $version2)
    {
        return version_compare($version1, $version2, '>=');
    }
}

class FileScanner
{
    private $deprecatedFunctions;
    private $codingStandardRules;

    public function __construct($deprecatedFunctions, $codingStandardRules)
    {
        $this->deprecatedFunctions = $deprecatedFunctions;
        $this->codingStandardRules = $codingStandardRules;
    }

    public function scanFile($filePath)
    {
        return [
            'Deprecated Functions' => $this->scanForDeprecatedFunctions($filePath),
            'SQL Injection' => $this->scanForSQLInjection($filePath),
            'XSS Vulnerabilities' => $this->scanForXSS($filePath),
            'Hardcoded Secrets' => $this->scanForSecrets($filePath),
            'File Inclusions' => $this->scanForInclusions($filePath),
            'Weak Passwords' => $this->scanForWeakPasswords($filePath),
            'Coding Standards' => $this->scanForCodingStandards($filePath),
            'CSRF Vulnerabilities' => $this->scanForCSRF($filePath), // New Check
            'Deploy Files' => $this->scanForDeploy($filePath),
       // 'File Upload Validation' => $this->scanForFileUploadValidation($filePath), // New Check
        //'Insecure Session Handling' => $this->scanForInsecureSessionHandling($filePath) // New Check

         
        ];
    }

// CSRF vulnerability detection function
private function scanForCSRF($filePath)
{
    $results = [];
    if (file_exists($filePath)) {
        $fileLines = file($filePath);
        $forms = [];

        // First pass: Detect forms and their CSRF tokens
        foreach ($fileLines as $lineNumber => $lineContent) {
            if (preg_match('/<form.*?method=["\']POST["\'].*?>/i', $lineContent)) {
                $formLine = $lineNumber + 1; // Keep track of the line number where the form starts

                // Check for CSRF token
                if (preg_match('/<input[^>]+type=["\']hidden["\'][^>]+name=["\']csrf_token["\'][^>]*>/i', $lineContent)) {
                    $forms[$formLine] = true; // Mark this form as having a CSRF token
                } else {
                    $forms[$formLine] = false; // No CSRF token
                }
            }
        }

        // Second pass: Check for CSRF validation in the form handling logic
        foreach ($fileLines as $lineNumber => $lineContent) {
            foreach ($forms as $formLine => $hasToken) {
                if ($hasToken) {
                    // Check if the CSRF token is validated in the processing logic
                    if (strpos($lineContent, '$_POST[\'csrf_token\']') !== false &&
                        strpos($lineContent, '$_SESSION[\'csrf_token\']') !== false) {
                        unset($forms[$formLine]); // Remove this form from the list if validation is found
                    }
                }
            }
        }

        // Log any forms that have CSRF tokens but are not validated
        foreach ($forms as $formLine => $hasToken) {
            if ($hasToken) {
                $results[] = "CSRF token included in form on line $formLine but not validated in $filePath.";
            }
        }
    }
    return $results;
}

private function scanForFileUploadValidation($filePath)
{
    $results = [];
    if (file_exists($filePath)) {
        $fileLines = file($filePath);
        foreach ($fileLines as $lineNumber => $lineContent) {
            // Check for file upload handling
            if (preg_match('/move_uploaded_file\s*\(\s*$_FILES\[\s*["\']\w+["\']\s*\]/', $lineContent) &&
                !preg_match('/if\s*\(\s*validates_uploaded_file\s*\(/', $lineContent)) {
                $results[] = "File upload detected on line " . ($lineNumber + 1) . " in $filePath. Ensure file validation is implemented.";
            }
        }
    }
    return $results;
}
private function scanForDeploy($filePath)
{
    $results = [];

    // Step 1: Define the search strings
    $timeForReportingString = '//timeforreporting';
    $monitorFunctionString = 'monitorAndCreateVersions($projectDir, $vcsDir, $metadataFile, $timestampFormat, $excludePatterns);';
    
    // Step 2: Read the script contents from the given file path
    if (!file_exists($filePath)) {
        $results[] = "File not found: $filePath";
        return $results;
    }

    $scriptContents = file_get_contents($filePath);

    // Step 3: Check if the //timeforreporting string is found
    if (strpos($scriptContents, $timeForReportingString) !== false) {
        // Uncomment the //timeforreporting string if it's present
        $scriptContents = str_replace($timeForReportingString, 'timeforreporting', $scriptContents);
        file_put_contents($filePath, $scriptContents);
        $results[] = "Uncommented //timeforreporting in $filePath.";
    }

    // Step 4: Check if the monitor function string is present
    if (strpos($scriptContents, $monitorFunctionString) !== false) {

        // Check specific lines where the monitoring function is found
        $fileFound = file($filePath);  // Read the file as an array of lines
        foreach ($fileFound as $lineNumber => $lineContent) {
            if (strpos($lineContent, $monitorFunctionString) !== false) {
                $results[] = "Monitoring function detected on line " . ($lineNumber + 1) . " in $filePath.";
            }
        }
    } else {
        // No monitoring function found, proceed with deployment
        
        // Step 5: Generate the next version number
       
       $currentVersion = '2.1.2';  
        //$newVersion = $this->generateNextVersion($currentVersion);
        $newVersion = $this->generateNextVersion($currentVersion, 'minor');
        //$newVersion = $this->generateNextVersion($currentVersion, 'major');
        

        // Step 6: Create backup folder
        $backupFolder = __DIR__ . '/backup/'. $newVersion;  // ;
        if (!is_dir($backupFolder)) {
            mkdir($backupFolder, 0777, true);  // Ensure the backup folder exists
        }

        // Step 7: Backup the current script
        $backupFilePath = $backupFolder . '/' . basename($filePath);
        if (!copy($filePath, $backupFilePath)) {
            $results[] = "Failed to back up $filePath to $backupFilePath.";
            error_log("Failed to back up file $filePath to $backupFilePath");
        } else {
            $results[] = "Successfully backed up $filePath to $backupFilePath.";
        }

        // Step 8: Create deploy folder if not exists
        $deployFolder = __DIR__ . '/deploy/' . $newVersion;  // Versioned subfolder in deploy
        if (!is_dir($deployFolder)) {
            mkdir($deployFolder, 0777, true);  // Create the versioned folder
        }

        // Step 9: Copy the deploy-ready script to the deploy folder
        $deployFilePath = $deployFolder . '/' . basename($filePath);
        if (!copy($filePath, $deployFilePath)) {
            $results[] = "Failed to copy $filePath to $deployFilePath.";
            error_log("Failed to copy file $filePath to $deployFilePath");
        } else {
            $results[] = "Successfully copied $filePath to $deployFilePath.";
        }
    }

    // Return the results array containing deployment status and line details
    return $results;
}

// Helper function to generate the next version
private function generateNextVersion($currentVersion, $incrementType = 'patch')
{
    // Assuming version format is major.minor.patch
    list($major, $minor, $patch) = explode('.', $currentVersion);

    // Determine which part of the version to increment
    switch ($incrementType) {
        case 'major':
            $major++;  // Increment major version
            $minor = 0;  // Reset minor and patch version after a major update
            $patch = 0;
            break;

        case 'minor':
            $minor++;  // Increment minor version
            $patch = 0;  // Reset patch version after a minor update
            break;

        case 'patch':
        default:
            $patch++;  // Increment patch version (default behavior)
            break;
    }

    // Return the new version in major.minor.patch format
    return "$major.$minor.$patch";
}
private function scanForInsecureSessionHandling($filePath)
{
    $results = [];
    if (file_exists($filePath)) {
        $fileLines = file($filePath);
        foreach ($fileLines as $lineNumber => $lineContent) {
            // Check if session_start() is used and validate secure flags
            if (preg_match('/session_start\s*\(\s*\)/', $lineContent) &&
                !preg_match('/session_set_cookie_params\s*\(\s*0,\s*["\']\/["\']/', $lineContent)) {
                $results[] = "Insecure session handling detected on line " . ($lineNumber + 1) . " in $filePath. Consider setting secure cookie parameters.";
            }
        }
    }
    return $results;
}
     
    private function scanForDeprecatedFunctions($filePath)
    {
        $results = [];
        if (file_exists($filePath)) {
            $fileLines = file($filePath);
            foreach ($fileLines as $lineNumber => $lineContent) {
                foreach ($this->deprecatedFunctions as $function => $suggestion) {
                    if (strpos($lineContent, $function) !== false) {
                        $results[] = "Deprecated function detected: $function on line " . ($lineNumber + 1) . " in $filePath. <b>Suggestion:</b> $suggestion";
                    }
                }
            }
        }
        return $results;
    }

    private function scanForSQLInjection($filePath)
    {
        $results = [];
        if (file_exists($filePath)) {
            $fileLines = file($filePath);
            foreach ($fileLines as $lineNumber => $lineContent) {
                if (preg_match('/mysqli_query\s*\(\s*[^,]*,\s*[^)]+/', $lineContent) ||
                    preg_match('/pdo_query\s*\(\s*[^,]*,\s*[^)]+/', $lineContent)) {
                    $results[] = "Potential SQL injection risk on line " . ($lineNumber + 1) . " in $filePath.";
                }
            }
        }
        return $results;
    }
private function scanForWeakPasswords($filePath)
{
    $results = [];
    if (file_exists($filePath)) {
        $fileLines = file($filePath);
        foreach ($fileLines as $lineNumber => $lineContent) {
            if (preg_match('/\b(?:password|secret|key|token)\b\s*[:=]\s*["\'](?:123456|password|admin|letmein)["\']/', $lineContent)) {
                $results[] = "Weak password detected on line " . ($lineNumber + 1) . " in $filePath.";
            }
        }
    }
    return $results;
}

    private function scanForXSS($filePath)
    {
        $results = [];
        if (file_exists($filePath)) {
            $fileLines = file($filePath);
            foreach ($fileLines as $lineNumber => $lineContent) {
                if (preg_match('/echo\s*\(\s*\$_(GET|POST|REQUEST|SERVER|COOKIE)/', $lineContent) ||
                    preg_match('/print\s*\(\s*\$_(GET|POST|REQUEST|SERVER|COOKIE)/', $lineContent)) {
                    $results[] = "Potential XSS risk on line " . ($lineNumber + 1) . " in $filePath. Check if user input is properly sanitized.";
                }
                if (preg_match('/(htmlspecialchars|htmlentities)\s*\(\s*\$_(GET|POST|REQUEST|SERVER|COOKIE)/', $lineContent) ||
                    preg_match('/filter_var\s*\(\s*\$_(GET|POST|REQUEST|SERVER|COOKIE)/', $lineContent)) {
                    $results[] = "Potential validation/sanitization check found on line " . ($lineNumber + 1) . " in $filePath.";
                }
            }
        }
        return $results;
    }

private function scanForSecrets($filePath)
{
    $results = [];
    if (file_exists($filePath)) {
        $fileLines = file($filePath);
        foreach ($fileLines as $lineNumber => $lineContent) {
            
            if (preg_match('/\b(?:password|secret|apikey|key|Admin|admin|token|username)\b\s*[:=]\s*["\'].*["\']/', $lineContent) ||
                preg_match('/\b(?:password|secret|apikey|key|Admin|admin|token|username)\b\s*[:=]\s*\'.*\'/', $lineContent) ) { // 
                $results[] = "Hardcoded secret detected on line " . ($lineNumber + 1) . " in $filePath.";
            }
        }
    }
    return $results;
}

    private function scanForInclusions($filePath)
    {
        $results = [];
        if (file_exists($filePath)) {
            $fileLines = file($filePath);
            foreach ($fileLines as $lineNumber => $lineContent) {
                if (preg_match('/\b(include|require)\b\s*["\']/', $lineContent) ||
                    preg_match('/\b(include_once|require_once)\b\s*["\']/', $lineContent)) {
                    $results[] = "File inclusion detected on line " . ($lineNumber + 1) . " in $filePath.";
                }
            }
        }
        return $results;
    }

    private function scanForCodingStandards($filePath)
    {
        $results = [];
        if (file_exists($filePath)) {
            $lines = file($filePath);
            $lineNumber = 1;

            foreach ($lines as $line) {
                $this->checkFunctionNaming($line, $lineNumber, $filePath, $results);
                $lineNumber++;
            }
        }
        return $results;
    }
    private function checkFunctionNaming($line, $lineNumber, $filePath, &$results)
    {
        if (preg_match('/function\s+([a-z][a-zA-Z0-9_]*)\s*\(/', $line, $matches)) {
            $functionName = $matches[1];
            if (!preg_match($this->codingStandardRules['function_naming'], $functionName)) {
                $results[] = "Function name '$functionName' should be in camelCase on line $lineNumber in $filePath.";
            }
        }
    }
    
}

class SecurityAudit
{
    private $directory;
    private $exclusions;
    private $scanner;

    public function __construct($directory, $exclusions, FileScanner $scanner)
    {
        $this->directory = $directory;
        $this->exclusions = $exclusions;
        $this->scanner = $scanner;
    }

    public function scan()
    {
        $results = [
            'Deprecated Functions' => [],
            'SQL Injection' => [],
            'XSS Vulnerabilities' => [],
            'Hardcoded Secrets' => [],
            'File Inclusions' => [],
            'Weak Passwords' => [],
            'Coding Standards' => [],
            'CSRF Vulnerabilities' => [],
            'Deploy Files' => []
           
           // 'File Upload Validation' => [], // New Check
    //    'Insecure Session Handling' => []
            //'Line Length Violations' => [] // New category
        ];

        $directoryIterator = new RecursiveDirectoryIterator($this->directory);
        $iterator = new RecursiveIteratorIterator($directoryIterator);

        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $relativePath = str_replace($this->directory . DIRECTORY_SEPARATOR, '', $file->getRealPath());

                // Skip excluded directories
                if ($this->isExcluded($relativePath)) {
                    continue;
                }

                $fileResults = $this->scanner->scanFile($file->getRealPath());
                foreach ($fileResults as $category => $issues) {
                    $results[$category] = array_merge($results[$category], $issues);
                }
            }
        }
        return $results;
    }

    private function isExcluded($relativePath)
    {
        foreach ($this->exclusions as $exclusion) {
            if (substr($exclusion, -1) === '/' && strpos($relativePath, rtrim($exclusion, '/')) === 0) {
                return true;
            } elseif (fnmatch($exclusion, $relativePath)) {
                return true;
            }
        }
        return false;
    }
}
// Main script
$scriptDir = __DIR__;

// Output the HTML report
echo "<html><head><style>
        body { font-family: Arial, sans-serif; }
        .container { width: 80%; margin: 0 auto; }
        h1 { text-align: center; }
        .category { margin-bottom: 20px; }
        .category h2 { background-color: #f4f4f4; padding: 10px; border-left: 5px solid #007BFF; }
        .category ul { list-style-type: none; padding: 0; }
        .category li { padding: 5px 0; }
        .warning { color: red; }
            .report-table { width: 100%; border-collapse: collapse; }
    .report-table th, .report-table td { border: 1px solid #ddd; padding: 8px; }
    .report-table th { background-color: #f4f4f4; }
        
    </style></head><body>";
echo "<div class='container'>";
echo "<h1>PHP Script Audit Tool</h1>";

// Check PHP version
echo "<div class='category'><h2>PHP Version</h2>";
$phpVersion = phpversion();
if (VersionChecker::versionCompare($phpVersion, Config::MIN_PHP_VERSION)) {
    echo "<p>PHP version is up-to-date: $phpVersion</p>";
} else {
    echo "<p class='warning'>WARNING: PHP version is outdated: $phpVersion</p>";
}
echo "</div>";

// Check PHPMailer version
echo "<div class='category'><h2>PHPMailer Version</h2>";
$phpMailerPath = 'phpmailer/src/PHPMailer.php'; // Update path as necessary
$phpMailerVersion = VersionChecker::getPHPMailerVersion($phpMailerPath);
if ($phpMailerVersion === 'Not available') {
    echo "<p class='warning'>WARNING: PHPMailer version is not available.</p>";
} elseif (VersionChecker::versionCompare($phpMailerVersion, Config::MIN_PHPMailER_VERSION)) {
    echo "<p>PHPMailer version is up-to-date: $phpMailerVersion</p>";
} else {
    echo "<p class='warning'>WARNING: PHPMailer version is outdated: $phpMailerVersion</p>";
}
echo "</div>";

// Check TCPDF version
echo "<div class='category'><h2>TCPDF Version</h2>";
$tcpdfPath = 'tcpdf/tcpdf.php'; // Update path as necessary
$tcpdfVersion = VersionChecker::getTCPDFVersion($tcpdfPath);
if ($tcpdfVersion === 'Not available') {
    echo "<p class='warning'>WARNING: TCPDF version is not available.</p>";
} elseif (VersionChecker::versionCompare($tcpdfVersion, Config::MIN_TCPDF_VERSION)) {
    echo "<p>TCPDF version is up-to-date: $tcpdfVersion</p>";
} else {
    echo "<p class='warning'>WARNING: TCPDF version is outdated: $tcpdfVersion</p>";
}
echo "</div>";

// Perform the scan on the directory
echo "<div class='category'><h2>Scan Results</h2>";
$scanner = new FileScanner(Config::DEPRECATED_FUNCTIONS, Config::CODING_STANDARD_RULES);
$audit = new SecurityAudit($scriptDir, Config::DEFAULT_EXCLUSIONS, $scanner);
$results = $audit->scan();

// Output results by category with counts
foreach ($results as $category => $issues) {
    $issueCount = count($issues);
    if ($issueCount > 0) {
        echo "<div class='category'><h2>$category - <span class='count'>$issueCount vulnerabilities found</span></h2><ul>";
        foreach ($issues as $issue) {
            echo "<li>$issue</li>";
        }
        echo "</ul></div>";
    }
    else{
         echo "<div class='category'><h2>$category - <span class='count'>No issues found</span></h2></div>";
    }
}

echo "</div></body></html>";
?>