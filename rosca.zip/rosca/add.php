<?php
//Start session
session_start();

//Check whether the session variable SESS_MEMBER_ID is present or not
if(!isset($_SESSION['SESSMEMBERID']) || (trim($_SESSION['SESSMEMBERID']) == '')) {
	header("location: index.php");
	exit();
}
?>
<?php
mysql_connect("localhost","root","");
mysql_select_db("rosca") or die("database could not connect ");
?>
<html>
<head>
<meta name="description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <script language="javascript" type="text/javascript">
/* Visit http://www.yaldex.com/ for full source code
and get more free JavaScript, CSS and DHTML scripts! */
<!-- Begin
var timerID = null;
var timerRunning = false;
function stopclock (){
if(timerRunning)
clearTimeout(timerID);
timerRunning = false;
}
function showtime () {
var now = new Date();
var hours = now.getHours();
var minutes = now.getMinutes();
var seconds = now.getSeconds()
var timeValue = "" + ((hours >12) ? hours -12 :hours)
if (timeValue == "0") timeValue = 12;
timeValue += ((minutes < 10) ? ":0" : ":") + minutes
timeValue += ((seconds < 10) ? ":0" : ":") + seconds
timeValue += (hours >= 12) ? " P.M." : " A.M."
document.clock.face.value = timeValue;
timerID = setTimeout("showtime()",1000);
timerRunning = true;
}
function startclock() {
stopclock();
showtime();
}
window.onload=startclock;
// End -->
</SCRIPT>
<title>Add Record</title>
</head>
<body>

<center>
<h1><u></u></h1>
</center>

<?php
if (isset($_POST["do"])=="NM"){
$aa=$_POST["ticfffnom"];
$bb=$_POST["ticflanom"];
$cc=$_POST["ticffinom"];
$dd=$_POST["ticflnnom"];
$ff=$_POST["ticfdob"];
$gg=$_POST["ticfstatus"];
$hh=$_POST["ticfeyc"];
$ii=$_POST["ticflang"];
$jj=$_POST["ticfhac"];
$kk=$_POST["ticfblo"];
$ll=$_POST["ticfmono"];
$mm=$_POST["ticffano"];
$nn=$_POST["ticffani"];
$oo=$_POST["ticfmoni"];
$query="insert into accounts
value(membership_id,'20211001','$aa','$bb','$cc','$dd','$ff','$gg','$hh','$ii','$jj','$kk','$ll','$mm','$nn','$oo')";
mysql_query($query);

}
else{
	echo " ";
}


if (isset($_POST["store"])=="NT"){
$today = date('Y-m-d');
$aa=$_POST["ticfeyc"];
$bb=$_POST["ticflanom"];
$cc=$_POST["ticffinom"];
$dd=$_POST["ticflbnom"];

$query="insert into collection
value(transaction_id,'$today','$aa','$bb','$cc','$dd')";
mysql_query($query);

}



else{
	echo " ";
}
?>
<table cellpadding="5px" cellspacing="0px"
align="center" border="0" >
<tr>
<td name="clock">
<form name="clock" name="face" value="">
<input style="width:150px;" type="submit" class="trans" name="face" value="">
</form>
</td>
</tr>
</table>
<form name="search" method="post" action="add.php">
<table cellpadding="5px" cellspacing="0px"
align="center" border="0">
<tr>
<td colspan="4" style="background:#0066FF; color:#FFFFFF; fontsize:20px">Search </td>
<td>&nbsp;</td>
</tr>
<tr>
<td>Enter Search Keyword</td>
<td><input type="text" name="search" size="40" /></td>
<td><input type="submit" value="Search" /></td>
</tr>
<tr bgcolor="#666666" style="color:#FFFFFF">
<td>Name</td>
<td>Total Collections</td>
<td>Balance</td>
<td>&nbsp;</td>
<?php
if (isset($_POST['search']))
{
$search=$_POST["search"];
$query="select * from collection where name like '%$search%'";
$result=mysql_query($query);
while ($row = mysql_fetch_array($result)) {
		echo "<tr><td bgcolor='color:green'>",$row[2],"</td>
		<td>",$row[3],"	</td>
		<td>",$row[5],"</td></tr>";
		}
echo "";
}
?>
<tr>
<td colspan="4">&nbsp;</td></tr>

</table>
</form>


<form name="new" method="post" action="add.php">
<table style=" border:1px solid silver" cellpadding="5px" cellspacing="0px"
align="center" border="0"  background="vulnerable.jpg">
<tr>
<td colspan="3" style="background:'white'; color:#FFFFFF; fontsize:20px; align:centre">
	</td>
	
	
</tr>
<tr>
<td colspan="4" align="center" style="background:#0066FF; color:#FFFFFF; fontsize:20pX">ADD RECORD</td>
</tr>
<tr>
<tr>

<td>Enter First Name</td>
<td><input type="text" name="ticfffnom" size="20"></td>
<td>Enter  Middle Name </td>
<td><input type="text" name="ticflanom" size="20"></td>
</tr>

<tr>

<td>Enter Last Name</td>
<td><input type="text" name="ticffinom" size="20"></td>
<td>Enter Contact Number</td>
<td><input type="text" name="ticflnnom" size="20"></td>
</tr>


<tr>
<td>Date Of Birth YYYY/MM/DD </td>
<td><input type="text" name="ticfdob" placeholder="YYYY/MM/DD" size="20"></td>
<td>Gender</td>
<td><select name="ticfstatus" class="span12">
<option value="">Gender</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
</select></td>
</tr>

<tr>
<td>Martial Status</td>
<td><select name="ticfeyc" class="span12">
<option value="">Martial Status</option>
<option value="Married">Married</option>
<option value="Single">Single</option>
<option value="Divorced">Divorced</option>
<option value="Widowed">Widowed</option>
<option value="Separated">Separated</option>
</select></td>
<td>Member Rank</td>
<td><input type="text" name="ticflang" size="20"></td>
<tr>
</tr>

<tr>
<td>Occupation</td>
<td><input type="text" name="ticfhac" size="20"></td>
<td>Email Address</td>
<td><input type="text" name="ticfblo" size="20"></td>
</tr>
<tr>
<td>Physical Address</td>
<td><input type="text" name="ticfmono" size="20"></td>
<td>Village</td>
<td><input type="text" name="ticffano" size="20"></td>
</tr>
<tr>
<td>Parish</td>
<td><input type="text" name="ticffani" size="20"></td>
<td>Sub county</td>
<td><input type="text" name="ticfmoni" size="20"></td>
</tr>
<tr>
<td colspan="4" align="center"><input type="hidden" name="do" value="NM">
<input type="submit" value="ADD RECORD"></td>
</tr>
</table>
</form>


<form name="add" method="post" action="add.php">
<table style=" border:1px solid silver" cellpadding="5px" cellspacing="0px"
align="center" border="0"  background="vulnerable.jpg">
<tr>
<td colspan="3" style="background:'white'; color:#FFFFFF; fontsize:20px; align:centre">
	</td>
	
	
</tr>
<tr>
<td colspan="4" align="center" style="background:#0066FF; color:#FFFFFF; fontsize:20pX">ADD RECORD</td>
</tr>
<tr>

<td> Select Name</td>
<td><select name="ticfeyc" class="span12">
<option value="">Name</option>
<?php
$query="select * from accounts where jdate ='20211001'";
$result=mysql_query($query);
while ($row = mysql_fetch_array($result)) {
	print '<option value="'.$row[2]." ".$row[3]." ".$row[4].'">'.$row[2]." ".$row[3]." ".$row[4].'</option>';
	}
echo "";
?>
</select></td>

<td>Enter  Amount </td>
<td><input type="text" name="ticflanom" size="20"></td>
</tr>

<tr>
<td>Enter Remarks</td>
<td><input type="text" name="ticffinom" size="20"></td>
<td>Enter Balance</td>
<td><input type="text" name="ticflbnom" size="20"></td>
</tr>

<tr>
<td colspan="4" align="center"><input type="hidden" name="store" value="NT">
<input type="submit" value="ADD RECORD"></td>
</tr>
</table>
</form>



</body>
</html>