<?php
	//Start session
session_start();
mysql_connect("localhost","root","");
mysql_select_db("rosca") or die("database could not connect ");
?>

<html>
<head>
<meta name="" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>LOGIN</title>
</head>
<body>
<center>
<h1><u></u></h1>
</center>

<?php
if (isset($_POST["do"])=="agrant"){
$selID=$_POST["ticflid"];
$selpsw=$_POST["ticflpsw"];


$query="select * from user where username ='$selID' and password = '$selpsw'";
$result=mysql_query($query);
if($result) {
	if(mysql_num_rows($result) > 0) {
		//Login Successful
		session_regenerate_id();
		$member = mysql_fetch_assoc($result);
		$_SESSION['SESSMEMBERID'] = $member['username'];
		session_write_close();
		header("location: add.php");
		exit();
	}else {
		//Login failed
		header("location: index.php");
		exit();
	}
}else {
	die("Query failed");
}
}
else{
}

?>
<form name="login" method="post" action="index.php">
<table style=" border:1px solid silver" cellpadding="5px" cellspacing="0px"
align="center" border="0">
<tr>
<td colspan="4" style="background:#0066FF; color:#FFFFFF; fontsize:
20px">LOGIN </td>
</tr>
<tr>
<tr>

<td>Enter Username</td>
<td><input type="text" name="ticflid" size="20"></td>
<td>Enter Password </td>
<td><input type="password" name="ticflpsw" size="20"></td>
</tr>

</tr>
<tr>
<td colspan="4" align="center"><input type="hidden" name="do" value="agrant">
<input type="submit" value="LOGIN"></td>
</tr>
</table>
</form>

</body>
</html>