<?php
	session_start();
	$_SESSION['SESSMEMBERID'] = false;
	session_destroy();
	header("location:index.php");
?>